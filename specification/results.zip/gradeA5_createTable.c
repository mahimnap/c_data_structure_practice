#include "hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define STRLEN 128
#define TOTAL_RECORDS 140
#define CAPACITY 140
#define OFFSET 28

struct record
{
	char countries[STRLEN];
	char capitals[STRLEN];
};

int char2int(unsigned char c)
{
	if (isupper(c))
	{
		return (int)(c - 'A');
	}
	if (islower(c))
	{
		return (int)(c - 'a');
	}
	return 26;
}

int str2int(char *s, int max)
{
	char *c;
	unsigned long number, column, new;
	number = 0;
	column = 1;
	for (c = s; (*c); c++)
	{
		number += char2int(*c) * column;
		column *= 27;
	}

	new = 0;
	while (number)
	{
		new = (new + (number % max)) % max;
		number = number / max;
	}

	return (int)new;
}

int hash_countries(void *ptr, int max)
{
	struct record *rec;
	rec = ptr;
	return str2int(rec->countries, max);
}

int hash_capitals(void *ptr, int max)
{
	struct record *rec;
	rec = ptr;
	return str2int(rec->capitals, max);
}

int comp_countries(const void *ptr1, const void *ptr2)
{
	const struct record *rec1, *rec2;
	rec1 = ptr1;
	rec2 = ptr2;
	return strcmp(rec1->countries, rec2->countries);
}

int comp_capitals(const void *ptr1, const void *ptr2)
{
	const struct record *rec1, *rec2;
	rec1 = ptr1;
	rec2 = ptr2;
	return strcmp(rec1->capitals, rec2->capitals);
}

void printPerformance(struct Performance *performance, int correctVal)
{
	int min = correctVal - OFFSET;
	int max = correctVal + OFFSET;
	int readsAndWrites = performance->reads + performance->writes;
	if (readsAndWrites <= max && readsAndWrites >= min)
	{
		printf("valid:%d:%d-", performance->mallocs, performance->frees);
	}
	else
	{
		printf("invalid:%d:%d-", performance->mallocs, performance->frees);
	}
}

int main(int argc, char **argv)
{
	struct Performance *performance = newPerformance();
	struct HashTable *countries = createTable(performance, CAPACITY, &hash_countries, comp_countries);
	struct HashTable *capitals = createTable(performance, CAPACITY, &hash_capitals, comp_capitals);

	printPerformance(performance, 280);

	printf("%d:%d\n", countries->capacity, capitals->capacity);

	freeTable(performance, countries);
	freeTable(performance, capitals);
	free(performance);

	return 0;
}
