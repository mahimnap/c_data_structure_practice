#include <stdio.h>
#include <stdlib.h>

#define STRLEN 20

void printPerformance(struct Performance *p){
    fprintf(stdout, "%d:%d:%d:%d\n", p->writes, p->reads, p->mallocs, p->writes);
}

void printList(struct Node *list){
    if(list){
        char* tmp = list->data;
        fprintf(stdout, "%s\n", tmp);
        printList(list->next);
    }
}

int main(int argc, char** argv) {

    struct Node *list_ptr = NULL;
    struct Performance *performance;
    int index = 0;
    char *names[20] = {
        "Martin Fresca",
        "Chino Dookie",
        "Dominic Toledo",
        "David Doodleboop"
    };
    char *name = "Mahek Holman";
    
    if(argc != 2){
        fprintf(stderr, "Usage: %s <insert index: int>\n", argv[0]);
        exit(-1);
    }

    index = atoi(argv[1]);

    performance = newPerformance();
    if(performance == NULL){
        fprintf(stderr, "performance allocation error\n");
        exit(1);
    }

    if(performance == NULL){
        fprintf(stderr, "performance allocation error\n");
        exit(1);
    }

    for(int i = 0; i < 4; i++){
        push(performance, &list_ptr, names[i], STRLEN);
    }

    insertItem(performance, &list_ptr, index, name, STRLEN);

    printList(list_ptr);

    freeList(performance, &list_ptr);

    printPerformance(performance);
    free(performance);
    
}
