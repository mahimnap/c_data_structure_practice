#include "hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define STRLEN 128
#define OFFSET 50

#define TOTAL_RECORDS 140
#define CAPACITY 140

#define TOTAL_RECORDS2 100
#define CAPACITY2 120

struct record
{
	char countries[STRLEN];
	char capitals[STRLEN];
};

struct record2
{
	char last_name[STRLEN];
	char first_name[STRLEN];
	char phone_number[13];
};

//////////////////////// TEST 1 Functions ////////////////////////

void read_file(struct record record[TOTAL_RECORDS])
{
	FILE *fp;
	char buffer[STRLEN];
	int i;

	fp = fopen("countries.txt", "r");
	fgets(buffer, STRLEN, fp);

	for (i = 0; i < TOTAL_RECORDS; i++)
	{
		fscanf(fp, "%s %s", record[i].countries, record[i].capitals);
	}

	fclose(fp);
}

int str2intCountries(char *s, int max)
{
	char *c;
	unsigned long number;
	number = 0;
	for (c = s; (*c); c++)
	{
		number *= 1299827;
		number += *c;
	}
	while (number > max)
	{
		number %= (max - 1);
		number += 1;
	}
	return (int)number;
}

int hash_captials(void *ptr, int max)
{
	struct record *rec;
	rec = ptr;
	return str2intCountries(rec->capitals, max);
}

int hash_countries(void *ptr, int max)
{
	struct record *rec;
	rec = ptr;
	return str2intCountries(rec->countries, max);
}

int comp_captials(const void *ptr1, const void *ptr2)
{
	const struct record *rec1, *rec2;
	int result;
	rec1 = ptr1;
	rec2 = ptr2;
	result = strcmp(rec1->capitals, rec2->capitals);
	return result;
}

int comp_countries(const void *ptr1, const void *ptr2)
{
	const struct record *rec1, *rec2;
	int result;
	rec1 = ptr1;
	rec2 = ptr2;
	result = strcmp(rec1->countries, rec2->countries);
	return result;
}

void printPerformance(struct Performance *performance, int correctVal)
{
	int min = correctVal - OFFSET;
	int max = correctVal + OFFSET;
	int readsAndWrites = performance->reads + performance->writes;
	if (readsAndWrites <= max && readsAndWrites >= min)
	{
		printf("valid:%d:%d-", performance->mallocs, performance->frees);
	}
	else
	{
		printf("invalid:%d:%d-", performance->mallocs, performance->frees);
	}
}

//////////////////////// TEST 2 Functions ////////////////////////

void read_file_2(struct record2 record2[TOTAL_RECORDS2])
{
	FILE *fp;
	char buffer[STRLEN];
	int i;

	fp = fopen("names1.txt", "r");
	fgets(buffer, STRLEN, fp);

	for (i = 0; i < TOTAL_RECORDS2; i++)
	{
		fscanf(fp, "%s %s", record2[i].first_name, record2[i].last_name);
		fscanf(fp, "%s", record2[i].phone_number);
	}

	fclose(fp);
}

int char2int(unsigned char c)
{
	if (isupper(c))
	{
		return (int)(c - 'A');
	}
	if (islower(c))
	{
		return (int)(c - 'a');
	}
	return 26;
}

int str2int(char *s, int max)
{
	char *c;
	unsigned long number, column, new;
	number = 0;
	column = 1;
	for (c = s; (*c); c++)
	{
		number += char2int(*c) * column;
		column *= 27;
	}
	new = 0;
	while (number)
	{
		new = (new + (number % max)) % max;
		number = number / max;
	}
	return (int)new;
}

int hash_first_name(void *ptr, int max)
{
	struct record2 *rec;
	rec = ptr;
	return str2int(rec->first_name, max);
}

int hash_last_name(void *ptr, int max)
{
	struct record2 *rec;
	rec = ptr;
	return str2int(rec->last_name, max);
}

int comp_first_name(const void *ptr1, const void *ptr2)
{
	const struct record2 *rec1, *rec2;
	int result;
	rec1 = ptr1;
	rec2 = ptr2;
	result = strcmp(rec1->first_name, rec2->first_name);

	return result;
}

int comp_last_name(const void *ptr1, const void *ptr2)
{
	const struct record2 *rec1, *rec2;
	int result;
	rec1 = ptr1;
	rec2 = ptr2;
	result = strcmp(rec1->last_name, rec2->last_name);
	return result;
}

void testOne()
{
	struct record record[TOTAL_RECORDS];
	struct Performance *performance = newPerformance();
	struct HashTable *countries = createTable(performance, CAPACITY, &hash_countries, comp_countries);
	struct record currentRecord;

	read_file(record);

	for (int i = 0; i < TOTAL_RECORDS; i++)
	{
		addElement(performance, countries, &(record[i]));
	}

	strcpy(currentRecord.countries, "Canada");
	removeElement(performance, countries, &currentRecord);

	strcpy(currentRecord.countries, "Lebanon");
	removeElement(performance, countries, &currentRecord);

	strcpy(currentRecord.countries, "Maldives");
	removeElement(performance, countries, &currentRecord);

	strcpy(currentRecord.countries, "Estonia");
	removeElement(performance, countries, &currentRecord);

	int preRehash = hashAccuracy(countries);
	rehash(countries);
	int postRehash = hashAccuracy(countries);

	printPerformance(performance, 889);

	if (postRehash < preRehash)
	{
		printf("improved\n");
	}
	else
	{
		printf("unimproved\n");
	}

	freeTable(performance, countries);
	free(performance);
}

void testTwo()
{
	struct record2 record2[TOTAL_RECORDS2];
	struct record2 rec;

	struct Performance *performance = newPerformance();
	struct HashTable *by_last_name;

	int i;

	read_file_2(record2);

	by_last_name = createTable(performance, CAPACITY2, &hash_last_name, comp_last_name);

	for (i = 0; i < TOTAL_RECORDS2; i++)
	{
		addElement(performance, by_last_name, &(record2[i]));
	}

	strcpy(rec.last_name, "Bonilla");
	removeElement(performance, by_last_name, &rec);

	strcpy(rec.last_name, "Jacobs");
	removeElement(performance, by_last_name, &rec);

	strcpy(rec.last_name, "Rowley");
	removeElement(performance, by_last_name, &rec);

	strcpy(rec.last_name, "Peterson");
	removeElement(performance, by_last_name, &rec);

	int preRehash = hashAccuracy(by_last_name);
	rehash(by_last_name);
	int postRehash = hashAccuracy(by_last_name);

	printPerformance(performance, 350);

	if (preRehash - postRehash >= 16)
	{
		printf("improved\n");
	}
	else
	{
		printf("unimproved\n");
	}

	freeTable(performance, by_last_name);
	free(performance);
}

int main(int argc, char **argv)
{
	if (argc != 2)
	{
		printf("Usage Incorrect - ./[exe] [1 - 2]\r\n");
		return -1;
	}
	if (strcmp(argv[1], "1") == 0)
	{
		testOne();
	}
	else if (strcmp(argv[1], "2") == 0)
	{
		testTwo();
	}
	else
	{
		printf("Usage incorrect - ./[exe] [1 - 2]\r\n");
	}
	return 0;
}
