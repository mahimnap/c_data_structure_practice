#include <stdio.h>
#include <stdlib.h>
#include "hash.h"

void printPerformance(struct Performance *performance)
{
	printf("%d:%d:%d:%d\r\n", performance->reads, performance->writes, performance->mallocs, performance->frees);
}

int main(int argc, char **argv)
{

	struct Performance *performance = newPerformance();
	if (performance != NULL)
	{
		printPerformance(performance);
	}
	else
	{
		printf("Failed to create and/or initialize new performance structure.\n");
	}
	free(performance);

	return 0;
}
