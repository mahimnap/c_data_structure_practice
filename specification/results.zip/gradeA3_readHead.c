#include <stdio.h>
#include <stdlib.h>

#define STRLEN 20

void printPerformance(struct Performance *p){
    fprintf(stdout, "%d:%d:%d:%d\n", p->writes, p->reads, p->mallocs, p->writes);
}

int main(int argc, char** argv) {

    struct Node *list_ptr = NULL;
    struct Performance *performance;
    char *names[20] = {
        "Esmay Meyers",
        "Hamish Wagner",
        "Zaki Mcfarland",
        "Shreya Mcdowell",
        "Pascal Reeve",
        "Sachin Leonard",
        "Tara Jennings",
        "Callum Atherton",
        "Ashton Noel",
        "Marwan Herrera"
    };

    char tmp[20] = "\0";
    performance = newPerformance();

    if(performance == NULL){
        fprintf(stderr, "performance allocation error\n");
        exit(1);
    }

    for(int i = 0; i < 10; i++){
        push(performance, &list_ptr, names[i], STRLEN);
    }

    readHead(performance, &list_ptr, tmp, STRLEN);
    printf("%s\n", tmp);

    freeList(performance, &list_ptr);

    printPerformance(performance);
    free(performance);
    
}
