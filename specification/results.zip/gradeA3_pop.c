#include <stdio.h>
#include <stdlib.h>

#define STRLEN 20

void printPerformance(struct Performance *p){
    fprintf(stdout, "%d:%d:%d:%d\n", p->writes, p->reads, p->mallocs, p->writes);
}

void printList(struct Node *list){
    if(list){
        char* tmp = list->data;
        fprintf(stdout, "%s\n", tmp);
        printList(list->next);
    }
}

int main(int argc, char** argv) {

    struct Node *list_ptr = NULL;
    struct Performance *performance;
    int index = 0;
    char *names[20] = {
        "Esmay Meyers",
        "Hamish Wagner",
        "Zaki Mcfarland",
        "Shreya Mcdowell",
        "Pascal Reeve",
        "Sachin Leonard",
        "Tara Jennings",
        "Callum Atherton",
        "Ashton Noel",
        "Marwan Herrera"
    };

    if(argc != 2){
        fprintf(stderr, "Usage: %s <number of names to pop from list: int>\n", argv[0]);
        exit(-1);
    }

    index = atoi(argv[1]);
    performance = newPerformance();

    if(performance == NULL){
        fprintf(stderr, "performance allocation error\n");
        exit(1);
    }

    for(int i = 0; i < 10; i++){
        push(performance, &list_ptr, names[i], STRLEN);
    }

    printf("POPPED:\n");
    for(int i = 0; i < index; i++){
        char temp[20];
        pop(performance, &list_ptr, temp, STRLEN);
        printf("%s\n", temp);
    }
    printf("LIST:\n");

    printList(list_ptr);

    freeList(performance, &list_ptr);

    printPerformance(performance);
    free(performance);
    
}
