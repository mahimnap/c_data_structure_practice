#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct City {
    char cityname[50];
    double lat;
    double lng;
    char country[50];
    int pop;
};

struct City *newCity(char *csvLine){
    struct City *city = malloc(sizeof(struct City));

    char tokens[6][50];

    const char* tok;
    int num = 0;
    for (tok = strtok(csvLine, ","); tok && *tok; tok = strtok(NULL, ",")) {
        strcpy(tokens[num], tok);
        num++;
    }

    strcpy(city->cityname, tokens[1]);
    strcpy(city->country, tokens[4]);
    city->pop = atoi(tokens[5]);
    city->lat = strtod(tokens[2], NULL);
    city->lng = strtod(tokens[3], NULL);

    return city;
}

void printCity(struct City* city){
    if(city)
        fprintf(stdout, "%s %lf %lf %s %d\n", city->cityname, city->lat, city->lng, city->country, city->pop);
    else 
        fprintf(stderr, "Null city\n");
}

void readFile(struct Performance *p, struct Node **list_ptr, char* filename){
    FILE *fp;

    fp = fopen(filename, "r");

    char *line = malloc(1024*sizeof(char));
    
    while(fgets(line, 1024, fp)){
        struct City *city = newCity(line);
        push(p, list_ptr, city, sizeof(struct City));
        free(city);
    }

    free(line);
    fclose(fp);
}

void printPerformance(struct Performance *p){
    fprintf(stdout, "%d:%d:%d:%d\n", p->writes, p->reads, p->mallocs, p->writes);
}

int compar(const void* a, const void* b){
    const struct City *at = a;
    const struct City *bt = b;

    return strcmp(at->cityname, bt->cityname);
}

int main(int argc, char **argv){

    struct Node *list_ptr = NULL;
    struct Performance *performance = NULL;
    int index = 0;
    struct City *temp = NULL;

    if(argc != 2){
        fprintf(stderr, "Usage: %s <cityname>\n", argv[0]);
        exit(-1);
    }

    performance = newPerformance();
    
    if(performance == NULL){
        fprintf(stderr, "performance allocation error\n");
        exit(1);
    }

    temp = malloc(sizeof(struct City));
    strcpy(temp->cityname, argv[1]);

    readFile(performance, &list_ptr, "../../../Graders/cities.csv");

    index = findItem(performance, &list_ptr, compar, temp, sizeof(struct City));
    if(index != -1){
        readItem(performance, &list_ptr, index, temp, sizeof(struct City));
        printCity(temp);
    }
    


    printf("%d\n", index);

    printPerformance(performance);    

    freeList(performance, &list_ptr);
    free(temp);
    free(performance);

}
