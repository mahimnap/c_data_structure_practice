#include <stdio.h>
#include <stdlib.h>

void readFile(struct Performance *p, struct Node **list_ptr, char* filename){
    FILE *fp;
    int num = 0;

    fp = fopen(filename, "r");

    while(!feof(fp)){
        if(fscanf(fp, "%d", &num)){
            push(p, list_ptr, &num, sizeof(int));
        }
    }

    fclose(fp);
}

void printPerformance(struct Performance *p){
    fprintf(stdout, "%d:%d:%d:%d\n", p->writes, p->reads, p->mallocs, p->writes);
}

int main(int argc, char** argv) {

    struct Node *list_ptr = NULL;
    struct Performance *performance;
    int index = 0;
    int num = 0;
    performance = newPerformance();

    if(argc != 2){
        fprintf(stderr, "Usage: %s <list index (between 0 and 9999): int>\n", argv[0]);
        exit(-1);
    }

    index = atoi(argv[1]);

    if(performance == NULL){
        fprintf(stderr, "performance allocation error\n");
        exit(1);
    }

    readFile(performance, &list_ptr, "../../../Graders/numbers.txt"); 

    readItem(performance, &list_ptr, index, &num, sizeof(int));
    fprintf(stdout, "%d\n", num);
    freeList(performance, &list_ptr);

    printPerformance(performance);
    free(performance);
}


