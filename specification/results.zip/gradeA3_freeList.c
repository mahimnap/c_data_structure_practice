#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void readFile(struct Performance *p, struct Node **list_ptr, char* filename){
    FILE *fp;
    int num = 0;

    fp = fopen(filename, "r");

    while(!feof(fp)){
        if(fscanf(fp, "%d", &num)){
            push(p, list_ptr, &num, sizeof(int));
        }
    }

    fclose(fp);
}

void printPerformance(struct Performance *p){
    fprintf(stdout, "%d:%d:%d:%d\n", p->writes, p->reads, p->mallocs, p->writes);
}

int main(int argc, char** argv) {

    struct Node *list_ptr = NULL;
    struct Performance *performance;
    int testEmptyList = 0;
    
    performance = newPerformance();

    if(argc != 2){
        fprintf(stderr, "Usage: %s <t/f: test empty list>\n", argv[0]);
        exit(-1);
    }

    if(strcmp(argv[1], "t") == 0)
        testEmptyList = 1;


    if(performance == NULL){
        fprintf(stderr, "performance allocation error\n");
        exit(1);
    }

    if(testEmptyList == 0)
        readFile(performance, &list_ptr, "../../../Graders/primes.txt"); 

    freeList(performance, &list_ptr);

    printPerformance(performance);
    free(performance);
}


