#include "hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define STRLEN 128
#define TOTAL_RECORDS 140
#define CAPACITY 140

struct record
{
	char countries[STRLEN];
	char capitals[STRLEN];
};

void read_file(struct record record[TOTAL_RECORDS])
{
	FILE *fp;
	char buffer[STRLEN];
	int i;

	fp = fopen("countries.txt", "r");
	fgets(buffer, STRLEN, fp);

	for (i = 0; i < TOTAL_RECORDS; i++)
	{
		fscanf(fp, "%s %s", record[i].countries, record[i].capitals);
	}

	fclose(fp);
}

int str2int(char *s, int max)
{
	char *c;
	unsigned long number;
	number = 0;
	for (c = s; (*c); c++)
	{
		number *= 1299827;
		number += *c;
	}
	while (number > max)
	{
		number %= (max - 1);
		number += 1;
	}
	return (int)number;
}

int hash_countries(void *ptr, int max)
{
	struct record *rec;
	rec = ptr;
	return str2int(rec->countries, max);
}

int hash_capitals(void *ptr, int max)
{
	struct record *rec;
	rec = ptr;
	return str2int(rec->capitals, max);
}

int comp_countries(const void *ptr1, const void *ptr2)
{
	const struct record *rec1, *rec2;
	rec1 = ptr1;
	rec2 = ptr2;
	return strcmp(rec1->countries, rec2->countries);
}

int comp_capitals(const void *ptr1, const void *ptr2)
{
	const struct record *rec1, *rec2;
	rec1 = ptr1;
	rec2 = ptr2;
	return strcmp(rec1->capitals, rec2->capitals);
}

// Case 1 - No collision: get element at empty hash location
void testOne()
{
	struct record record[TOTAL_RECORDS];
	struct Performance *performance = newPerformance();
	struct HashTable *countries = createTable(performance, CAPACITY, &hash_countries, comp_countries);
	struct HashTable *capitals = createTable(performance, CAPACITY, &hash_capitals, comp_capitals);
	int index1, index2, index3 = 0;

	read_file(record);

	addElement(performance, countries, &(record[5])); //49
	addElement(performance, capitals, &(record[5]));
	addElement(performance, countries, &(record[10])); //127
	addElement(performance, capitals, &(record[10]));
	addElement(performance, countries, &(record[15])); //98
	addElement(performance, capitals, &(record[15]));

	index1 = getIdx(performance, countries, &(record[5]));
	index2 = getIdx(performance, countries, &(record[10]));
	index3 = getIdx(performance, countries, &(record[15]));

	printf("%d:%d:%d:%d:%d\n", index1, index2, index3, performance->mallocs, performance->frees);

	freeTable(performance, countries);
	freeTable(performance, capitals);
	free(performance);
}

// Case 2 - Collision: move 2 spots down to get element
void testTwo()
{
	struct record record[TOTAL_RECORDS];
	struct Performance *performance = newPerformance();
	struct HashTable *countries = createTable(performance, CAPACITY, &hash_countries, comp_countries);

	read_file(record);

	addElement(performance, countries, &(record[67]));
	addElement(performance, countries, &(record[71]));
	addElement(performance, countries, &(record[104]));

	int index = getIdx(performance, countries, &(record[104]));

	printf("%d:%d:%d-%s\n", index, performance->mallocs, performance->frees, (char *)countries->data[index]);

	freeTable(performance, countries);
	free(performance);
}

// Case 3 - Collision: loop entire hash table and get element at end of table
void testThree()
{
	struct record record[TOTAL_RECORDS];
	struct Performance *performance = newPerformance();
	struct HashTable *countries = createTable(performance, CAPACITY, &hash_countries, comp_countries);

	read_file(record);

	for (int i = 0; i < TOTAL_RECORDS; i++)
	{
		addElement(performance, countries, &(record[i]));
	}

	int index = getIdx(performance, countries, "Botswana");

	printf("%d:%d:%d-%s\n", index, performance->mallocs, performance->frees, (char *)countries->data[index]);

	freeTable(performance, countries);
	free(performance);
}

// Case 4 - Element not found in table
void testFour()
{
	struct record record[TOTAL_RECORDS];
	struct Performance *performance = newPerformance();
	struct HashTable *countries = createTable(performance, CAPACITY, &hash_countries, comp_countries);

	read_file(record);

	for (int i = 0; i < TOTAL_RECORDS; i++)
	{
		addElement(performance, countries, &(record[i]));
	}

	int index = getIdx(performance, countries, "Ontario");

	printf("%d:%d:%d\n", index, performance->mallocs, performance->frees);

	freeTable(performance, countries);
	free(performance);
}

int main(int argc, char **argv)
{
	if (argc != 2)
	{
		printf("Usage Incorrect - ./[exe] [1 - 4]\r\n");
		return -1;
	}
	if (strcmp(argv[1], "1") == 0)
	{
		testOne();
	}
	else if (strcmp(argv[1], "2") == 0)
	{
		testTwo();
	}
	else if (strcmp(argv[1], "3") == 0)
	{
		testThree();
	}
	else if (strcmp(argv[1], "4") == 0)
	{
		testFour();
	}
	else
	{
		printf("Usage incorrect - ./[exe] [1 - 4]\r\n");
	}
	return 0;
}
