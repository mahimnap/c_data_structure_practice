#include <stdio.h>
#include <stdlib.h>

#define STRLEN 20

void printPerformance(struct Performance *p){
    fprintf(stdout, "%d:%d:%d:%d\n", p->writes, p->reads, p->mallocs, p->writes);
}

int main(int argc, char** argv) {

    struct Node *list_ptr = NULL;
    struct Node **temp = NULL;
    struct Performance *performance;
    int index = 0;
    char *names[20] = {
        "Esmay Meyers",
        "Hamish Wagner",
        "Zaki Mcfarland",
        "Shreya Mcdowell",
        "Pascal Reeve",
        "Sachin Leonard",
        "Tara Jennings",
        "Callum Atherton",
        "Ashton Noel",
        "Marwan Herrera"
    };

    if(argc == 2){
        index = atoi(argv[1]);
    }
    else{
        fprintf(stderr, "Usage: %s <index to print: number>\n", argv[0]);
        exit(-1);
    }

    char *tmp;
    performance = newPerformance();

    if(performance == NULL){
        fprintf(stderr, "performance allocation error\n");
        exit(1);
    }

    for (int i = 0; i < 10; i++) {
        push(performance, &list_ptr, names[i], STRLEN);
    }

    temp = &list_ptr;
    for(int i = 0; i < index; i++){
        temp = next(performance, temp);
    }
    
    tmp = (*temp)->data;
    printf("%s\n", tmp);

    freeList(performance, &list_ptr);

    printPerformance(performance);
    free(performance);
}
