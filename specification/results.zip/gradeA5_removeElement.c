#include "hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define STRLEN 128
#define CAPACITY 3

struct record
{
    char countries[STRLEN];
    char capitals[STRLEN];
};

int char2int(unsigned char c)
{
    if (isupper(c))
    {
        return (int)(c - 'A');
    }
    if (islower(c))
    {
        return (int)(c - 'a');
    }
    return 26;
}

int str2int(char *s, int max)
{
    char *c;
    unsigned long number, column, new;
    number = 0;
    column = 1;
    for (c = s; (*c); c++)
    {
        number += char2int(*c) * column;
        column *= 27;
    }

    new = 0;
    while (number)
    {
        new = (new + (number % max)) % max;
        number = number / max;
    }

    return (int)new;
}

int hash_countries(void *ptr, int max)
{
    struct record *rec;
    rec = ptr;
    return str2int(rec->countries, max);
}

int hash_capitals(void *ptr, int max)
{
    struct record *rec;
    rec = ptr;
    return str2int(rec->capitals, max);
}

int comp_countries(const void *ptr1, const void *ptr2)
{
    const struct record *rec1, *rec2;
    rec1 = ptr1;
    rec2 = ptr2;
    return strcmp(rec1->countries, rec2->countries);
}

int comp_capitals(const void *ptr1, const void *ptr2)
{
    const struct record *rec1, *rec2;
    rec1 = ptr1;
    rec2 = ptr2;
    return strcmp(rec1->capitals, rec2->capitals);
}

void printPerformance(struct Performance *performance)
{
    int readAndWrites = performance->reads + performance->writes;
    printf("%d:%d:%d-", readAndWrites, performance->mallocs, performance->frees);
}

int main(int argc, char **argv)
{
    struct record currentRecord;
    struct Performance *performance = newPerformance();
    struct HashTable *countries = createTable(performance, CAPACITY, &hash_countries, comp_countries);

    addElement(performance, countries, "Canada");
    addElement(performance, countries, "Mexico");
    addElement(performance, countries, "Scotland");

    printf("%d-", countries->nel);

    strcpy(currentRecord.countries, "Canada");
    removeElement(performance, countries, &currentRecord);
    strcpy(currentRecord.countries, "Mexico");
    removeElement(performance, countries, &currentRecord);
    strcpy(currentRecord.countries, "Scotland");
    removeElement(performance, countries, &currentRecord);

    printPerformance(performance);

    if ((countries->data[0] == NULL) && (countries->data[1] == NULL) && (countries->data[2] == NULL) && (countries->nel == 0))
    {
        printf("%d\n", countries->nel);
    }
    else
    {
        printf("incorrect\n");
    }

    freeTable(performance, countries);
    free(performance);
    return 0;
}
