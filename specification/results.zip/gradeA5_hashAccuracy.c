#include "hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define STRLEN 128
#define TOTAL_RECORDS 100
#define CAPACITY 120
#define OFFSET 35

struct record
{
	char last_name[STRLEN];
	char first_name[STRLEN];
	char phone_number[13];
};

void read_file(struct record record[TOTAL_RECORDS])
{
	FILE *fp;
	char buffer[STRLEN];
	int i;

	fp = fopen("names1.txt", "r");
	fgets(buffer, STRLEN, fp);

	for (i = 0; i < TOTAL_RECORDS; i++)
	{
		fscanf(fp, "%s %s", record[i].first_name, record[i].last_name);
		fscanf(fp, "%s", record[i].phone_number);
	}

	fclose(fp);
}

int char2int(unsigned char c)
{
	if (isupper(c))
	{
		return (int)(c - 'A');
	}
	if (islower(c))
	{
		return (int)(c - 'a');
	}
	return 26;
}

int str2int(char *s, int max)
{
	char *c;
	unsigned long number, column, new;
	number = 0;
	column = 1;
	for (c = s; (*c); c++)
	{
		number += char2int(*c) * column;
		column *= 27;
	}
	new = 0;
	while (number)
	{
		new = (new + (number % max)) % max;
		number = number / max;
	}
	return (int)new;
}

int hash_first_name(void *ptr, int max)
{
	struct record *rec;
	rec = ptr;
	return str2int(rec->first_name, max);
}

int hash_last_name(void *ptr, int max)
{
	struct record *rec;
	rec = ptr;
	return str2int(rec->last_name, max);
}

int comp_first_name(const void *ptr1, const void *ptr2)
{
	const struct record *rec1, *rec2;
	int result;
	rec1 = ptr1;
	rec2 = ptr2;
	result = strcmp(rec1->first_name, rec2->first_name);
	return result;
}

int comp_last_name(const void *ptr1, const void *ptr2)
{
	const struct record *rec1, *rec2;
	int result;
	rec1 = ptr1;
	rec2 = ptr2;
	result = strcmp(rec1->last_name, rec2->last_name);
	return result;
}

void printPerformance(struct Performance *performance, int correctVal)
{
	int min = correctVal - OFFSET;
	int max = correctVal + OFFSET;
	int readsAndWrites = performance->reads + performance->writes;
	if (readsAndWrites <= max && readsAndWrites >= min)
	{
		printf("valid:%d:%d-", performance->mallocs, performance->frees);
	}
	else
	{
		printf("invalid:%d:%d-", performance->mallocs, performance->frees);
	}
}

void testOne()
{
	struct record record[TOTAL_RECORDS];
	struct record rec;

	struct Performance *performance = newPerformance();
	struct HashTable *by_last_name = createTable(performance, CAPACITY, &hash_last_name, comp_last_name);

	read_file(record);

	for (int i = 0; i < TOTAL_RECORDS; i++)
	{
		addElement(performance, by_last_name, &(record[i]));
	}

	strcpy(rec.last_name, "Bonilla");
	removeElement(performance, by_last_name, &rec);

	strcpy(rec.last_name, "Jacobs");
	removeElement(performance, by_last_name, &rec);

	strcpy(rec.last_name, "Rowley");
	removeElement(performance, by_last_name, &rec);

	strcpy(rec.last_name, "Peterson");
	removeElement(performance, by_last_name, &rec);

	printPerformance(performance, 350);

	printf("%d-%d\n", hashAccuracy(by_last_name), by_last_name->nel);

	freeTable(performance, by_last_name);
	free(performance);
}

void testTwo()
{
	struct record record[TOTAL_RECORDS];
	struct record rec;

	struct Performance *performance = newPerformance();
	struct HashTable *by_last_name = createTable(performance, CAPACITY, &hash_last_name, comp_last_name);

	read_file(record);

	for (int i = 0; i < TOTAL_RECORDS; i++)
	{
		addElement(performance, by_last_name, &(record[i]));
	}

	strcpy(rec.last_name, "Neville");
	removeElement(performance, by_last_name, &rec);

	printPerformance(performance, 343);

	printf("%d-%d\n", hashAccuracy(by_last_name), by_last_name->nel);

	freeTable(performance, by_last_name);
	free(performance);
}

int main(int argc, char **argv)
{

	if (argc != 2)
	{
		printf("Usage Incorrect - ./[exe] [1 - 2]\r\n");
		return -1;
	}

	if (strcmp(argv[1], "1") == 0)
	{
		testOne();
	}
	else if (strcmp(argv[1], "2") == 0)
	{
		testTwo();
	}
	else
	{
		printf("Usage incorrect - ./[exe] [1 - 2]\r\n");
	}

	return 0;
}
