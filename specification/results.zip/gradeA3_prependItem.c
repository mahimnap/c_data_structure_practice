#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printList(struct Node *list){
    if(list){
        char* tmp = list->data;
        fprintf(stdout, "%s", tmp);
        printList(list->next);
    }
}

int main(int argc, char** argv){

    struct Performance *p = newPerformance();
    struct Node **list = NULL;
    struct Node *head = NULL;
    char temp = '\0';
    char *str = NULL;

    if(argc != 3){
        fprintf(stderr, "Usage: %s <string> <char to prepend>\n", argv[0]);
        exit(-1);
    }

    str = argv[1];
    temp = argv[2][0];

    list = &head;

    for(int i = 0; i < strlen(str); i++){
        push(p, list, &(str[i]), sizeof(char));
    }

    prependItem(p, list, &temp, sizeof(char));

    printList(*list);
    printf("\n");

    freeList(p, list);
    free(p);

    return 0;
}
